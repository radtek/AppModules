// "Therefore those skilled at the unorthodox
// are infinite as heaven and earth,
// inexhaustible as the great rivers.
// When they come to an end,
// they bagin again,
// like the days and months;
// they die and are reborn,
// like the four seasons."
// 
// - Sun Tsu,
// "The Art of War"

using System.Drawing;
using System.Drawing.Drawing2D;
using HtmlRenderer.Dom;
using HtmlRenderer.Entities;
using HtmlRenderer.Properties;

namespace HtmlRenderer.Utils
{
    /// <summary>
    /// Provides some drawing functionallity
    /// </summary>
    internal static class DrawingUtils
    {
        #region Fields and Consts

        /// <summary>
        /// image used to draw loading image icon
        /// </summary>
        private static Image _loadImage;

        /// <summary>
        /// image used to draw error image icon
        /// </summary>
        private static Image _errorImage;

        /// <summary>
        /// used for all border paint to use the same points and not create new array each time.
        /// </summary>
        private static readonly PointF[] _borderPts = new PointF[4];

        #endregion


        /// <summary>
        /// Makes the specified color darker
        /// </summary>
        /// <param name="c"></param>
        /// <returns></returns>
        public static Color Darken(Color c)
        {
            return Color.FromArgb(c.R / 2, c.G / 2, c.B / 2);
        }

        /// <summary>
        /// Draw image loading icon.
        /// </summary>
        /// <param name="g">the device to draw into</param>
        /// <param name="r">the rectangle to draw icon in</param>
        public static void DrawImageLoadingIcon(Graphics g, RectangleF r)
        {
            g.DrawRectangle(Pens.LightGray, r.Left + 3, r.Top + 3, 13, 14);
            var image = GetLoadImage();
            g.DrawImage(image, r.Left + 4, r.Top + 4, image.Width, image.Height);
        }

        /// <summary>
        /// Draw image failed to load icon.
        /// </summary>
        /// <param name="g">the device to draw into</param>
        /// <param name="r">the rectangle to draw icon in</param>
        public static void DrawImageErrorIcon(Graphics g, RectangleF r)
        {
            g.DrawRectangle(Pens.LightGray, r.Left + 2, r.Top + 2, 15, 15);
            var image = GetErrorImage();
            g.DrawImage(image, r.Left + 3, r.Top + 3, image.Width, image.Height);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="border">Desired border</param>
        /// <param name="g">the device to draw to</param>
        /// <param name="box">Box wich the border corresponds</param>
        /// <param name="brush">the brush to use</param>
        /// <param name="rectangle">the bounding rectangle to draw in</param>
        /// <param name="isLineStart">Specifies if the border is for a starting line (no bevel on left)</param>
        /// <param name="isLineEnd">Specifies if the border is for an ending line (no bevel on right)</param>
        /// <returns>Beveled border path, null if there is no rounded corners</returns>
        public static void DrawBorder(Border border, Graphics g, CssBox box, Brush brush, RectangleF rectangle, bool isLineStart, bool isLineEnd)
        {
            var borderPath = DrawingUtils.GetRoundedBorderPath(border, box, rectangle, isLineStart, isLineEnd);
            if(borderPath != null)
            {
                var smooth = g.SmoothingMode;
                if (box.HtmlContainer != null && !box.HtmlContainer.AvoidGeometryAntialias && box.IsRounded)
                    g.SmoothingMode = SmoothingMode.AntiAlias;

                using (borderPath)
                    g.FillPath(brush, borderPath);

                g.SmoothingMode = smooth;
            }
            else
            {
                SetBorderRectanglePoints(border, box, rectangle, isLineStart, isLineEnd);
                g.FillPolygon(brush, _borderPts);                
            }
        }

        /// <summary>
        /// Creates a rounded rectangle using the specified corner radius
        /// </summary>
        /// <param name="rect">Rectangle to round</param>
        /// <param name="nwRadius">Radius of the north east corner</param>
        /// <param name="neRadius">Radius of the north west corner</param>
        /// <param name="seRadius">Radius of the south east corner</param>
        /// <param name="swRadius">Radius of the south west corner</param>
        /// <returns>GraphicsPath with the lines of the rounded rectangle ready to be painted</returns>
        public static GraphicsPath GetRoundRect(RectangleF rect, float nwRadius, float neRadius, float seRadius, float swRadius)
        {
            //  NW-----NE
            //  |       |
            //  |       |
            //  SW-----SE

            GraphicsPath path = new GraphicsPath();

            nwRadius *= 2;
            neRadius *= 2;
            seRadius *= 2;
            swRadius *= 2;

            //NW ---- NE
            path.AddLine(rect.X + nwRadius, rect.Y, rect.Right - neRadius, rect.Y);
            
            //NE Arc
            if (neRadius > 0f)
            {
                path.AddArc(
                    RectangleF.FromLTRB(rect.Right - neRadius, rect.Top, rect.Right, rect.Top + neRadius),
                    -90, 90);
            }

            // NE
            //  |
            // SE
            path.AddLine(rect.Right, rect.Top + neRadius, rect.Right, rect.Bottom - seRadius);

            //SE Arc
            if (seRadius > 0f)
            {
                path.AddArc(
                    RectangleF.FromLTRB(rect.Right - seRadius, rect.Bottom - seRadius, rect.Right, rect.Bottom),
                    0, 90);
            }

            // SW --- SE
            path.AddLine(rect.Right - seRadius, rect.Bottom, rect.Left + swRadius, rect.Bottom);

            //SW Arc
            if (swRadius > 0f)
            {
                path.AddArc(
                    RectangleF.FromLTRB(rect.Left, rect.Bottom - swRadius, rect.Left + swRadius, rect.Bottom),
                    90, 90);
            }

            // NW
            // |
            // SW
            path.AddLine(rect.Left, rect.Bottom - swRadius, rect.Left, rect.Top + nwRadius);

            //NW Arc
            if (nwRadius > 0f)
            {
                path.AddArc(
                    RectangleF.FromLTRB(rect.Left, rect.Top, rect.Left + nwRadius, rect.Top + nwRadius),
                    180, 90);
            }

            path.CloseFigure();

            return path;
        }


        #region Private methods

        /// <summary>
        /// Makes a border path for rounded borders.<br/>
        /// Return null if the border is not rounded.
        /// </summary>
        /// <param name="border">Desired border</param>
        /// <param name="b">Box wich the border corresponds</param>
        /// <param name="r"></param>
        /// <param name="isLineStart">Specifies if the border is for a starting line (no bevel on left)</param>
        /// <param name="isLineEnd">Specifies if the border is for an ending line (no bevel on right)</param>
        /// <returns>Beveled border path, null if there is no rounded corners</returns>
        private static void SetBorderRectanglePoints(Border border, CssBox b, RectangleF r, bool isLineStart, bool isLineEnd)
        {
            switch (border)
            {
                case Border.Top:
                    _borderPts[0] = new PointF(r.Left, r.Top);
                    _borderPts[1] = new PointF(r.Right, r.Top);
                    _borderPts[2] = new PointF(r.Right, r.Top + b.ActualBorderTopWidth);
                    _borderPts[3] = new PointF(r.Left, r.Top + b.ActualBorderTopWidth);
                    if (isLineEnd) _borderPts[2].X -= b.ActualBorderRightWidth;
                    if (isLineStart) _borderPts[3].X += b.ActualBorderLeftWidth;
                    break;
                case Border.Right:
                    _borderPts[0] = new PointF(r.Right - b.ActualBorderRightWidth, r.Top + b.ActualBorderTopWidth);
                    _borderPts[1] = new PointF(r.Right, r.Top);
                    _borderPts[2] = new PointF(r.Right, r.Bottom);
                    _borderPts[3] = new PointF(r.Right - b.ActualBorderRightWidth, r.Bottom - b.ActualBorderBottomWidth);
                    break;
                case Border.Bottom:
                    _borderPts[0] = new PointF(r.Left, r.Bottom - b.ActualBorderBottomWidth);
                    _borderPts[1] = new PointF(r.Right, r.Bottom - b.ActualBorderBottomWidth);
                    _borderPts[2] = new PointF(r.Right, r.Bottom);
                    _borderPts[3] = new PointF(r.Left, r.Bottom);
                    if (isLineStart) _borderPts[0].X += b.ActualBorderLeftWidth;
                    if (isLineEnd) _borderPts[1].X -= b.ActualBorderRightWidth;
                    break;
                case Border.Left:
                    _borderPts[0] = new PointF(r.Left, r.Top);
                    _borderPts[1] = new PointF(r.Left + b.ActualBorderLeftWidth, r.Top + b.ActualBorderTopWidth);
                    _borderPts[2] = new PointF(r.Left + b.ActualBorderLeftWidth, r.Bottom - b.ActualBorderBottomWidth);
                    _borderPts[3] = new PointF(r.Left, r.Bottom);
                    break;
            }
        }

        /// <summary>
        /// Makes a border path for rounded borders.<br/>
        /// Return null if the border is not rounded.
        /// </summary>
        /// <param name="border">Desired border</param>
        /// <param name="b">Box wich the border corresponds</param>
        /// <param name="r"></param>
        /// <param name="isLineStart">Specifies if the border is for a starting line (no bevel on left)</param>
        /// <param name="isLineEnd">Specifies if the border is for an ending line (no bevel on right)</param>
        /// <returns>Beveled border path, null if there is no rounded corners</returns>
        private static GraphicsPath GetRoundedBorderPath(Border border, CssBox b, RectangleF r, bool isLineStart, bool isLineEnd)
        {
            PointF[] pts = null;
            GraphicsPath corner = null;

            switch (border)
            {
                case Border.Top:
                    if (b.ActualCornerNW > 0 || b.ActualCornerNE > 0 || b.ActualCornerNE > 0 || b.ActualCornerNW > 0)
                    {
                        float bwidth = b.ActualBorderTopWidth;
                        pts = new PointF[4];
                        pts[0] = new PointF(r.Left + b.ActualCornerNW, r.Top);
                        pts[1] = new PointF(r.Right - b.ActualCornerNE, r.Top);
                        pts[2] = new PointF(r.Right - b.ActualCornerNE, r.Top + bwidth);
                        pts[3] = new PointF(r.Left + b.ActualCornerNW, r.Top + bwidth);

                        if (isLineEnd && b.ActualCornerNE < .1f) pts[2].X -= b.ActualBorderRightWidth;
                        if (isLineStart && b.ActualCornerNW < .1f) pts[3].X += b.ActualBorderLeftWidth;

                        if (b.ActualCornerNW > 0f)
                            corner = CreateCorner(b, r, 1);
                    }
                    break;
                case Border.Right:
                    if (b.ActualCornerNE > 0 || b.ActualCornerSE > 0)
                    {
                        var bwidth = b.ActualBorderRightWidth;
                        pts = new PointF[4];
                        pts[0] = new PointF(r.Right - bwidth, r.Top + b.ActualCornerNE);
                        pts[1] = new PointF(r.Right, r.Top + b.ActualCornerNE);
                        pts[2] = new PointF(r.Right, r.Bottom - b.ActualCornerSE);
                        pts[3] = new PointF(r.Right - bwidth, r.Bottom - b.ActualCornerSE);

                        if (b.ActualCornerNE < .1f) pts[0].Y += b.ActualBorderTopWidth;
                        if (b.ActualCornerSE < .1f) pts[3].Y -= b.ActualBorderBottomWidth;

                        if (b.ActualCornerNE > 0f)
                            corner = CreateCorner(b, r, 2);
                    }
                    break;
                case Border.Bottom:
                    if (b.ActualCornerSW > 0 || b.ActualCornerSE > 0 || b.ActualCornerSE > 0 || b.ActualCornerSW > 0)
                    {
                        var bwidth = b.ActualBorderBottomWidth;
                        pts = new PointF[4];
                        pts[0] = new PointF(r.Left + b.ActualCornerSW, r.Bottom - bwidth);
                        pts[1] = new PointF(r.Right - b.ActualCornerSE, r.Bottom - bwidth);
                        pts[2] = new PointF(r.Right - b.ActualCornerSE, r.Bottom);
                        pts[3] = new PointF(r.Left + b.ActualCornerSW, r.Bottom);

                        if (isLineStart && b.ActualCornerSW < .1f) pts[0].X += b.ActualBorderLeftWidth;
                        if (isLineEnd && b.ActualCornerSE < .1f) pts[1].X -= b.ActualBorderRightWidth;

                        if (b.ActualCornerSE > 0f) corner = CreateCorner(b, r, 3);
                    }
                    break;
                case Border.Left:
                    if (b.ActualCornerNW > 0 || b.ActualCornerSW > 0)
                    {
                        var bwidth = b.ActualBorderLeftWidth;
                        pts = new PointF[4];
                        pts[0] = new PointF(r.Left, r.Top + b.ActualCornerNW);
                        pts[1] = new PointF(r.Left + bwidth, r.Top + b.ActualCornerNW);
                        pts[2] = new PointF(r.Left + bwidth, r.Bottom - b.ActualCornerSW);
                        pts[3] = new PointF(r.Left, r.Bottom - b.ActualCornerSW);

                        if (b.ActualCornerNW < .1f) pts[1].Y += b.ActualBorderTopWidth;
                        if (b.ActualCornerSW < .1f) pts[2].Y -= b.ActualBorderBottomWidth;

                        if (b.ActualCornerSW > 0f) corner = CreateCorner(b, r, 4);
                    }
                    break;
            }

            GraphicsPath path = null;
            if (pts != null)
            {
                path = new GraphicsPath(pts, new[] { (byte)PathPointType.Line, (byte)PathPointType.Line, (byte)PathPointType.Line, (byte)PathPointType.Line });
                if (corner != null)
                {
                    path.AddPath(corner, true);
                }
            }

            return path;
        }

        /// <summary>
        /// Creates the corner to place with the borders
        /// </summary>
        private static GraphicsPath CreateCorner(CssBox b, RectangleF r, int cornerIndex)
        {
            GraphicsPath corner = new GraphicsPath();

            RectangleF outer = RectangleF.Empty;
            RectangleF inner = RectangleF.Empty;
            float start1 = 0;
            float start2 = 0;

            switch (cornerIndex)
            {
                case 1:
                    outer = new RectangleF(r.Left, r.Top, b.ActualCornerNW, b.ActualCornerNW);
                    inner = RectangleF.FromLTRB(outer.Left + b.ActualBorderLeftWidth, outer.Top + b.ActualBorderTopWidth, outer.Right, outer.Bottom);
                    start1 = 180;
                    start2 = 270;
                    break;
                case 2:
                    outer = new RectangleF(r.Right - b.ActualCornerNE, r.Top, b.ActualCornerNE, b.ActualCornerNE);
                    inner = RectangleF.FromLTRB(outer.Left, outer.Top + b.ActualBorderTopWidth, outer.Right - b.ActualBorderRightWidth, outer.Bottom);
                    outer.X -= outer.Width;
                    inner.X -= inner.Width;
                    start1 = -90;
                    start2 = 0;
                    break;
                case 3:
                    outer = RectangleF.FromLTRB(r.Right - b.ActualCornerSE, r.Bottom - b.ActualCornerSE, r.Right, r.Bottom);
                    inner = new RectangleF(outer.Left, outer.Top, outer.Width - b.ActualBorderRightWidth, outer.Height - b.ActualBorderBottomWidth);
                    outer.X -= outer.Width;
                    outer.Y -= outer.Height;
                    inner.X -= inner.Width;
                    inner.Y -= inner.Height;
                    start1 = 0;
                    start2 = 90;
                    break;
                case 4:
                    outer = new RectangleF(r.Left, r.Bottom - b.ActualCornerSW, b.ActualCornerSW, b.ActualCornerSW);
                    inner = RectangleF.FromLTRB(r.Left + b.ActualBorderLeftWidth, outer.Top, outer.Right, outer.Bottom - b.ActualBorderBottomWidth);
                    start1 = 90;
                    start2 = 180;
                    outer.Y -= outer.Height;
                    inner.Y -= inner.Height;
                    break;
            }

            if (outer.Width <= 0f) outer.Width = 1f;
            if (outer.Height <= 0f) outer.Height = 1f;
            if (inner.Width <= 0f) inner.Width = 1f;
            if (inner.Height <= 0f) inner.Height = 1f;


            outer.Width *= 2;
            outer.Height *= 2;
            inner.Width *= 2;
            inner.Height *= 2;

            outer = RoundR(outer);
            inner = RoundR(inner);

            corner.AddArc(outer, start1, 90);
            corner.AddArc(inner, start2, -90);

            corner.CloseFigure();

            return corner;
        }

        /// <summary>
        /// Rounds the specified rectangle
        /// </summary>
        private static RectangleF RoundR(RectangleF r)
        {
            //HACK: Don't round if in printing mode
            return Rectangle.Round(r);
        }

        /// <summary>
        /// Get singleton instance of load image.
        /// </summary>
        /// <returns>image instance</returns>
        private static Image GetLoadImage()
        {
            if (_loadImage == null)
                _loadImage = Resources.LoadImage;
            return _loadImage;
        }

        /// <summary>
        /// Get singleton instance of error image.
        /// </summary>
        /// <returns>image instance</returns>
        private static Image GetErrorImage()
        {
            if (_errorImage == null)
                _errorImage = Resources.ErrorImage;
            return _errorImage;
        }

        #endregion
    }
}
