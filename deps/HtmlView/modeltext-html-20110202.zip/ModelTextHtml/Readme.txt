Please send feedback to http://groups.google.com/group/modeltext:

- Bug reports, or suggestions for improving this control
- Proposals or questions about developing or commercialising this control.

Contents of this package:

* ModelEditControl.dll -- the control

* ModelEditControl.xml -- intellisense documentation; see also http://www.modeltext.com/html/apis.aspx and http://www.modeltext.com/html/apis/Index.html for further details

* license.txt -- the license

* Examples -- source code with an example of how to use this file.